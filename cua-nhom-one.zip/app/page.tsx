
"use client";

import { useState } from "react";

export default function Home() {
  const [order, setOrder] = useState({
    customer: "",
    doorType: "",
    width: "",
    height: "",
  });

  const handleChange = (e) => {
    setOrder({ ...order, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    alert(`Tạo đơn thành công cho khách hàng ${order.customer}`);
    setOrder({ customer: "", doorType: "", width: "", height: "" });
  };

  return (
    <main className="p-6 grid gap-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold">Tạo đơn sản xuất cửa nhôm</h1>
      <div className="grid gap-4 p-4 border rounded-xl bg-white shadow">
        <input
          name="customer"
          placeholder="Tên khách hàng"
          value={order.customer}
          onChange={handleChange}
          className="border p-2 rounded"
        />
        <input
          name="doorType"
          placeholder="Loại cửa (cửa đi, cửa sổ...)"
          value={order.doorType}
          onChange={handleChange}
          className="border p-2 rounded"
        />
        <input
          name="width"
          placeholder="Chiều rộng (mm)"
          value={order.width}
          onChange={handleChange}
          className="border p-2 rounded"
        />
        <input
          name="height"
          placeholder="Chiều cao (mm)"
          value={order.height}
          onChange={handleChange}
          className="border p-2 rounded"
        />
        <button onClick={handleSubmit} className="bg-blue-500 text-white p-2 rounded">
          Tạo đơn hàng
        </button>
      </div>
    </main>
  );
}
